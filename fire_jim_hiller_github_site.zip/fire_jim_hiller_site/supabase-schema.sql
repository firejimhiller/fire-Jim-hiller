-- FIRE JIM HILLER fan site: Supabase schema
-- Run this entire file in Supabase -> SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text not null unique check (char_length(username) between 3 and 20),
  created_at timestamptz not null default now()
);

create or replace function public.create_profile_for_user()
returns trigger language plpgsql security definer set search_path = public
as $$
declare chosen_username text;
begin
  chosen_username := coalesce(new.raw_user_meta_data->>'username', 'leafsfan');
  insert into public.profiles(id, username)
  values(new.id, chosen_username)
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created_profile on auth.users;
create trigger on_auth_user_created_profile
after insert on auth.users
for each row execute procedure public.create_profile_for_user();

create table if not exists public.petition_signatures (
  id bigint generated always as identity primary key,
  email_digest text not null unique,
  created_at timestamptz not null default now()
);
alter table public.petition_signatures enable row level security;
-- Intentionally no public SELECT/INSERT policies. The RPCs below are the only public interface.

create or replace function public.sign_petition(p_email text)
returns text language plpgsql security definer set search_path = public, extensions
as $$
declare normalized text;
begin
  normalized := lower(trim(p_email));
  if normalized !~ '^[^@\s]+@[^@\s]+\.[^@\s]+$' then return 'invalid'; end if;
  insert into public.petition_signatures(email_digest)
  values(encode(digest(normalized, 'sha256'), 'hex'))
  on conflict (email_digest) do nothing;
  if found then return 'signed'; else return 'duplicate'; end if;
end;
$$;

create or replace function public.get_signature_count()
returns bigint language sql security definer set search_path = public
as $$ select count(*) from public.petition_signatures; $$;

revoke all on function public.sign_petition(text) from public;
grant execute on function public.sign_petition(text) to anon, authenticated;
revoke all on function public.get_signature_count() from public;
grant execute on function public.get_signature_count() to anon, authenticated;

create table if not exists public.comments (
  id bigint generated always as identity primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  body text not null check (char_length(trim(body)) between 2 and 400),
  created_at timestamptz not null default now()
);
alter table public.comments enable row level security;

create table if not exists public.comment_likes (
  id bigint generated always as identity primary key,
  comment_id bigint not null references public.comments(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique(comment_id, user_id)
);
alter table public.comment_likes enable row level security;

alter table public.profiles enable row level security;
drop policy if exists "Profiles are publicly readable" on public.profiles;
create policy "Profiles are publicly readable" on public.profiles for select using (true);
drop policy if exists "Users can update their own profile" on public.profiles;
create policy "Users can update their own profile" on public.profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);

drop policy if exists "Comments are publicly readable" on public.comments;
create policy "Comments are publicly readable" on public.comments for select using (true);
drop policy if exists "Signed-in users can post comments" on public.comments;
create policy "Signed-in users can post comments" on public.comments for insert to authenticated with check (auth.uid() = user_id);
drop policy if exists "Users can delete their own comments" on public.comments;
create policy "Users can delete their own comments" on public.comments for delete to authenticated using (auth.uid() = user_id);

drop policy if exists "Likes are publicly readable" on public.comment_likes;
create policy "Likes are publicly readable" on public.comment_likes for select using (true);
drop policy if exists "Signed-in users can like" on public.comment_likes;
create policy "Signed-in users can like" on public.comment_likes for insert to authenticated with check (auth.uid() = user_id);
drop policy if exists "Users can remove their own likes" on public.comment_likes;
create policy "Users can remove their own likes" on public.comment_likes for delete to authenticated using (auth.uid() = user_id);

grant usage on schema public to anon, authenticated;
grant select on public.profiles, public.comments, public.comment_likes to anon, authenticated;
grant insert, delete on public.comments, public.comment_likes to authenticated;
grant update(username) on public.profiles to authenticated;
grant usage, select on all sequences in schema public to authenticated;

-- IMPORTANT:
-- In Supabase Dashboard -> Authentication -> Sign In / Providers -> Email,
-- disable "Confirm email" to allow password accounts without email verification.
-- Do not expose your service_role key in app.js or GitHub.
