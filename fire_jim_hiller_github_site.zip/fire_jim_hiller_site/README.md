# FIRE JIM HILLER — GitHub Pages website

A satirical Leafs fan petition and public comment wall. The site is a static website hosted free on GitHub Pages, with Supabase providing the live petition counter, signatures, accounts, comments and likes.

## Files
- `index.html` — page structure
- `styles.css` — responsive styling
- `app.js` — website behaviour and Supabase connection
- `supabase-schema.sql` — database tables, policies and safe petition RPCs
- `assets/jim-hiller.jpeg` — supplied image

## 1. Create the free backend
1. Create a project at https://supabase.com/.
2. Open **SQL Editor** in the Supabase dashboard.
3. Paste all of `supabase-schema.sql` and run it.
4. Open **Authentication → Sign In / Providers → Email** and turn off **Confirm email**. This enables accounts without email verification.
5. In **Project Settings → API**, copy the Project URL and the `anon` / publishable public key.

## 2. Connect the website
Open `app.js` and replace:
```js
const SUPABASE_URL = "YOUR_SUPABASE_PROJECT_URL";
const SUPABASE_ANON_KEY = "YOUR_SUPABASE_ANON_KEY";
```
with your project URL and anon/public key. The anon/public key is intended for browser use when Row Level Security is configured. **Never use the `service_role` key here.**

## 3. Publish on GitHub Pages
1. Create a new GitHub repository.
2. Upload every file and folder from this project (keep `assets` as a folder).
3. In the repository, open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Choose `main` and `/ (root)`, then Save.
6. Wait for GitHub Pages to publish and open the URL shown in Pages settings.

## Features
- Petition signatures: email only, no account or verification; one signature per normalized email. Emails are never publicly readable. The database stores a SHA-256 digest, not the plain email.
- Comments: account required; username is public, email is not.
- Likes: one per account per comment; users cannot like their own posts.
- Sorting: most liked or newest.
- Users can delete their own comments.

## Important notes before sharing publicly
- A petition without email verification cannot prove that an email address belongs to the signer. The unique digest prevents repeat submissions using the same normalized email, but people can use multiple addresses.
- The site includes basic client-side filtering, not robust moderation. Client-side filters can be bypassed. For a public launch, add server-side moderation, CAPTCHA/rate limiting, and a report/administrator moderation workflow.
- The Supabase free tier has usage limits. Check current plan limits before expecting large traffic.
- This is an unofficial satirical fan project, not affiliated with the Toronto Maple Leafs, MLSE, Jim Hiller or the NHL.
- Review local privacy requirements and provide a contact/privacy policy before collecting real visitor emails.
